For convenience you can just type:
"make syn" for synthesis
"make sim" for simulation, then click RUN in the GUI
please make sure you "source /vol/eecs392/env/questasim.env" before the simulation

If you don’t trust it, you can also check the sim or syn folders and handle things as you prefer.